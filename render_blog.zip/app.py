
from flask import Flask, render_template, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("DATABASE_URL", "sqlite:///blog.db")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.getenv("SECRET_KEY", "your_secret_key")

db = SQLAlchemy(app)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    excerpt = db.Column(db.String(200))
    content = db.Column(db.Text)
    likes = db.Column(db.Integer, default=0)
    views = db.Column(db.Integer, default=0)

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'))
    user_email = db.Column(db.String(100))
    comment = db.Column(db.Text)

@app.route('/')
def index():
    posts = Post.query.all()
    return render_template('index.html', posts=posts)

@app.route('/post/<int:post_id>')
def post(post_id):
    post = Post.query.get_or_404(post_id)
    post.views += 1
    db.session.commit()
    comments = Comment.query.filter_by(post_id=post_id).all()
    return render_template('post.html', post=post, comments=comments)

@app.route('/like/<int:post_id>', methods=['POST'])
def like(post_id):
    post = Post.query.get_or_404(post_id)
    post.likes += 1
    db.session.commit()
    return redirect(f'/post/{post_id}')

@app.route('/comment/<int:post_id>', methods=['POST'])
def comment(post_id):
    comment_text = request.form.get('comment')
    user_email = request.cookies.get('user_email', 'anonymous')
    new_comment = Comment(post_id=post_id, comment=comment_text, user_email=user_email)
    db.session.add(new_comment)
    db.session.commit()
    return redirect(f'/post/{post_id}')

@app.route('/set_user', methods=['POST'])
def set_user():
    data = request.json
    resp = jsonify(success=True)
    resp.set_cookie('user_email', data.get('email'))
    return resp

if __name__ == '__main__':
    app.run(debug=True)
