
from flask import Flask, render_template, request, redirect, jsonify, session, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("DATABASE_URL", "sqlite:///blog.db")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = os.getenv("SECRET_KEY", "your_secret_key")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

db = SQLAlchemy(app)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    excerpt = db.Column(db.String(200))
    content = db.Column(db.Text)
    likes = db.Column(db.Integer, default=0)
    views = db.Column(db.Integer, default=0)

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'))
    user_email = db.Column(db.String(100))
    comment = db.Column(db.Text)

@app.route('/')
def index():
    posts = Post.query.all()
    return render_template('index.html', posts=posts)

@app.route('/post/<int:post_id>')
def post(post_id):
    post = Post.query.get_or_404(post_id)
    post.views += 1
    db.session.commit()
    comments = Comment.query.filter_by(post_id=post_id).all()
    return render_template('post.html', post=post, comments=comments)

@app.route('/like/<int:post_id>', methods=['POST'])
def like(post_id):
    post = Post.query.get_or_404(post_id)
    post.likes += 1
    db.session.commit()
    return redirect(f'/post/{post_id}')

@app.route('/comment/<int:post_id>', methods=['POST'])
def comment(post_id):
    comment_text = request.form.get('comment')
    user_email = request.cookies.get('user_email', 'anonymous')
    new_comment = Comment(post_id=post_id, comment=comment_text, user_email=user_email)
    db.session.add(new_comment)
    db.session.commit()
    return redirect(f'/post/{post_id}')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form['password'] == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect('/admin')
    return render_template('admin_login.html')

@app.route('/admin')
def admin_dashboard():
    if not session.get('admin'):
        return redirect('/admin/login')
    posts = Post.query.all()
    return render_template('admin_dashboard.html', posts=posts)

@app.route('/admin/new', methods=['GET', 'POST'])
def admin_new():
    if not session.get('admin'):
        return redirect('/admin/login')
    if request.method == 'POST':
        new_post = Post(
            title=request.form['title'],
            excerpt=request.form['excerpt'],
            content=request.form['content']
        )
        db.session.add(new_post)
        db.session.commit()
        return redirect('/admin')
    return render_template('admin_new.html')

@app.route('/admin/edit/<int:post_id>', methods=['GET', 'POST'])
def admin_edit(post_id):
    if not session.get('admin'):
        return redirect('/admin/login')
    post = Post.query.get_or_404(post_id)
    if request.method == 'POST':
        post.title = request.form['title']
        post.excerpt = request.form['excerpt']
        post.content = request.form['content']
        db.session.commit()
        return redirect('/admin')
    return render_template('admin_edit.html', post=post)

@app.route('/admin/delete/<int:post_id>')
def admin_delete(post_id):
    if not session.get('admin'):
        return redirect('/admin/login')
    post = Post.query.get_or_404(post_id)
    db.session.delete(post)
    db.session.commit()
    return redirect('/admin')

@app.route('/set_user', methods=['POST'])
def set_user():
    data = request.json
    resp = jsonify(success=True)
    resp.set_cookie('user_email', data.get('email'))
    return resp

if __name__ == '__main__':
    app.run(debug=True)
